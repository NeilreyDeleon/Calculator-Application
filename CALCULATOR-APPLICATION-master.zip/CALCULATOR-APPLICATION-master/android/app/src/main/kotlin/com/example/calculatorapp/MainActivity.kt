package com.example.calculatorapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
